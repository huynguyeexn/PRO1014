<?php

require_once('controllers/ProductController.php');