<?php

require_once('controllers/BlogController.php');
?>