<?php

require_once 'core/connect.php';

?>