 <!--================Blog Categorie Area =================-->
 <section class="blog_categorie_area">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="categories_post">
                        <img src="assets/img/blog/cat-post/2.jpg" alt="post">
                        <div class="categories_details">
                            <div class="categories_text">
                                <a href="blog-details.html">
                                    <h5>Nghệ thuật</h5>
                                </a>
                                <div class="border_line"></div>
                                <p>Nghệ thuật là một trải nghiệm</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="categories_post">
                        <img src="assets/img/blog/cat-post/4.jpg" alt="post">
                        <div class="categories_details">
                            <div class="categories_text">
                                <a href="blog-details.html">
                                    <h5>Thời trang</h5>
                                </a>
                                <div class="border_line"></div>
                                <p>Tận hưởng xu hướng thời trang của bạn</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="categories_post">
                        <img src="assets/img/blog/cat-post/3.jpg" alt="post">
                        <div class="categories_details">
                            <div class="categories_text">
                                <a href="blog-details.html">
                                    <h5>Sneaker</h5>
                                </a>
                                <div class="border_line"></div>
                                <p>Mang lại sức mạnh cho các bước đi</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================Blog Categorie Area =================-->