<section class="features-area section_gap">
		<div class="container">
			<div class="row features-inner">
				<!-- single features -->
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="single-features">
						<div class="f-icon">
							<img src="assets/img/features/f-icon1.png" alt="">
						</div>
						<h6>Miễn phí giao hàng</h6>
						<p>Miễn phí giao hàng khi mua đơn hàng trên 1 triệu đồng.</p>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="single-features">
						<div class="f-icon">
							<img src="assets/img/features/f-icon2.png" alt="">
						</div>
						<h6>Đổi trả miễn phí</h6>
						<p>Miễn phí đổi trả khi sản phẩm lỗi</p>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="single-features">
						<div class="f-icon">
							<img src="assets/img/features/f-icon3.png" alt="">
						</div>
						<h6>Hỗ trợ 24/7</h6>
						<p>Liên hệ với chúng tôi khi bạn cần</p>
					</div>
				</div>
				<!-- single features -->
				<div class="col-lg-3 col-md-6 col-sm-6">
					<div class="single-features">
						<div class="f-icon">
							<img src="assets/img/features/f-icon4.png" alt="">
						</div>
						<h6>Bảo hành</h6>
						<p>Bảo hành trọn đời.</p>
					</div>
				</div>
			</div>
		</div>
	</section>